package com.log;

public class CallProgram {
	int time;
	boolean start;
	
	public CallProgram(int time, boolean start) {
		this.time=time;
		this.start=start;
	}
	
}
