package com.log;

public class CallLog {
		int start;
		int end;
		
		public CallLog (int start, int end) {
			this.start=start;
			this.end=end;
		}
}
